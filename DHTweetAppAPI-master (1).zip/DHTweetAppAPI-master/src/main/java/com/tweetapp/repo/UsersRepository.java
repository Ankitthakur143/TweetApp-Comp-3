package com.tweetapp.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetapp.model.Users;

@Repository
public class UsersRepository {

	@Autowired
	private DynamoDBMapper mapper;

	public Users findByUserName(String userName) {
		return mapper.load(Users.class, userName);
	}
	
	public Users save(Users user) {
		mapper.save(user);
		return user;
	}

	public List<Users> findAll(){
		return mapper.scan(Users.class, new DynamoDBScanExpression());
	}

}
