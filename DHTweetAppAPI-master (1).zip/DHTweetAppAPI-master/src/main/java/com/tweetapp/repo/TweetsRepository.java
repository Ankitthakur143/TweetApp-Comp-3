package com.tweetapp.repo;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.tweetapp.model.Tweets;

@EnableScan
@Repository
public class TweetsRepository {

	@Autowired
	private DynamoDBMapper mapper;

	public Tweets save(Tweets tweet) {
		mapper.save(tweet);
		return tweet;
	}

	public List<Tweets> findAll() {
		return mapper.scan(Tweets.class, new DynamoDBScanExpression());
	}

	public List<Tweets> findByUserName(String userName) {
		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
		scanExpression.addFilterCondition("userName", new Condition().withComparisonOperator(ComparisonOperator.EQ)
				.withAttributeValueList(new AttributeValue().withS(userName)));
		return mapper.scan(Tweets.class, scanExpression);
	}

	public Tweets findById(String tweetId) {
		return mapper.load(Tweets.class, tweetId);
	}

	public String deleteById(String id) {
		mapper.delete(mapper.load(Tweets.class, id));
		return ("Tweet deleted: " + id);
	}
}
